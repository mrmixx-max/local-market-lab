"""Local Market Lab module."""
